<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-joget mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<style>
    .image_upload>input {
        display: none;
    }

    /* input[type=text]{width:220px;height:auto;} */
</style>
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    NB : KLICK LOGO UNTUK MENGGANTI.
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#edit" class="btn-sm bt-1 float-right mt-1" title="EDIT"><i class="fa fa-edit"></i></a>
                                </x>
                                <div class="small">&nbsp;&nbsp;Extension : 'png','svg'</div>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="col">
                                <small>
                                    <strong>
                                        Logo instansi
                                    </strong>
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-6">
                        <center>
                            <small><strong><small>POSITIFE</small></strong></small>
                            <span class="image_upload">
                                <label for="btn_logo_p">
                                    <a class="btn" rel="nofollow" id="btn_img">
                                        <div id="logo_p">
                                            <img src="<?= XROOT . 'img/instansi/' . inc("logo") ?>" width="100%">
                                        </div>
                                    </a>
                                </label>
                                <input type="file" name="btn_logo_p" id="btn_logo_p">
                            </span>
                        </center>
                    </div>
                    <div class="col-md-12 col-6">
                        <center>
                            <small><strong><small>NEGATIFE</small></strong></small>
                            <span class="image_upload">
                                <label for="btn_logo_n">
                                    <a class="btn" rel="nofollow" id="btn_img">
                                        <div id="logo_n">
                                            <img src="<?= XROOT . 'img/instansi/' . inc("logo-n") ?>" width="100%">
                                        </div>
                                    </a>
                                </label>
                                <input type="file" name="btn_logo_n" id="btn_logo_n">
                            </span>
                        </center>
                    </div>
                </div>

            </div>
            <div class="col-md-10">
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Nama Aplikasi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("app-name") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Judul
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("app-name-2") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Nama Instansi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("nama-instansi") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Email Instansi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("email") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            No. Telp / Fax
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("telp") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            No. HP / Wa
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("hp") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Slogan
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("slogan") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Alamat Instansi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("alamat") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Deskripsi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("desk-app") ?>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-12">
                        <div class="card bg-1">
                            <div class="col">
                                <small>
                                    <strong>
                                        TAMPILAN LOGIN
                                    </strong>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <x>
                                Login img Backround
                                <a href="javascript:voit(0);" class="float-right image_upload" title="Ganti">
                                    <label for="btn_img_wave">
                                        <i class="fa fa-edit"></i>
                                    </label>
                                    <input type="file" name="btn_img_wave" id="btn_img_wave">
                                </a>
                            </x>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div id="wave_l">
                                <img src="<?= XROOT ?>img/dev/<?= inc("wave-login") ?>" alt="wave" width="30%">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <x> Login Deskripsi<a href="javascript:voit(0);" data-toggle="modal" data-target="#edit2" class="float-right" title="Edit"><i class="fa fa-edit"></i></a></x>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc("desk-login") ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                SERTIFIKAT
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mb-2">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Domain / URL
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= XURL ?>
                        </div>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            MODUL
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc('modul') ?>
                        </div>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Tanggal Aktifasi
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= date("d-m-Y", inc('tgl-regist')) ?>
                        </div>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Tanggal Expire
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= inc('sertificate_expire') ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="_user"><i class="fa fa-edit mr-2"></i>Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">

                <form action="" method="post" enctype="multipart/form-data">

                    <div class="row">
                        <div class="col-md-6">
                            <small>Nama Aplikasi</small>
                            <input type="text" class="form-control" name="app_name" value="<?= inc("app-name") ?>" required>
                            <small>Judul Aplikasi</small>
                            <input type="text" class="form-control" name="app_name2" value="<?= inc("app-name-2") ?>" required>
                            <small>Nama Instansi</small>
                            <input type="text" class="form-control" name="nama_instansi" value="<?= inc("nama-instansi") ?>" required>
                            <small>Email Instansi</small>
                            <input type="email" class="form-control" name="email" value="<?= inc("email") ?>" required>
                        </div>
                        <div class="col-md-6">
                            <small>No. Telp / Fax</small>
                            <input type="text" class="form-control" name="telp" value="<?= inc("telp") ?>" required>
                            <small>No. HP / Wa</small>
                            <input type="text" class="form-control mb-2" name="hp" value="<?= inc("hp") ?>" required>
                            <small>Alamat Instansi</small>
                            <textarea name="alamat" id="alamat" class="form-control" rows="3"><?= inc("alamat") ?></textarea>
                        </div>
                        <div class="col-12">
                            <small>SLOGAN</small>
                            <input type="text" class="form-control" name="slogan" value="<?= inc("slogan") ?>" required>
                        </div>
                        <div class="col-12">
                            <small>Deskripsi</small>
                            <textarea name="desk" id="desk" class="form-control" rows="4"><?= inc("desk-app") ?></textarea>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</button>
            </div>

            </form>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="_user"><i class="fa fa-edit mr-2"></i>Edit Deskripsi login</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">

                <form action="" method="post" enctype="multipart/form-data">
                    <textarea name="desk2" id="desk2" class="form-control" rows="6"><?= inc("desk-login") ?></textarea>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</button>
            </div>

            </form>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    $('#desk').summernote({
        height: 240,
        // themes:paper,
        airMode: false
    })
    $('#desk2').summernote({
        height: 600,
        // themes:paper,
        airMode: false
    })
    //===========================================
    $(document).ready(function() {
        $('#btn_logo_p').on('change', function() {
            var url = '<?= XROOT ?>inc/upload_logo/logo';
            var property = document.getElementById('btn_logo_p').files[0];
            var image_name = property.name;
            var image_extension = image_name.split('.').pop().toLowerCase();
            var e = image_extension;
            if (e !== 'png' && e !== 'svg') {
                toastr.error('Logo Extensi Harus [ png , svg].');
                exit;
            }
            var form_data = new FormData();
            form_data.append("file", property);

            $.ajax({
                url: url,
                method: 'POST',
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    toastr.success('Logo Positife Berhasil Di Ganti.');
                    $('#logo_p').html(data);
                }
            });
        });
        $('#btn_logo_n').on('change', function() {
            var url = '<?= XROOT ?>inc/upload_logo/logo-n';
            var property = document.getElementById('btn_logo_n').files[0];
            var image_name = property.name;
            var image_extension = image_name.split('.').pop().toLowerCase();
            var e = image_extension;
            if (e !== 'png' && e !== 'svg') {
                toastr.error('Logo Extensi Harus [ png , svg].');
                exit;
            }
            var form_data = new FormData();
            form_data.append("file", property);

            $.ajax({
                url: url,
                method: 'POST',
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    toastr.success('Logo Negatife Berhasil Di Ganti.');
                    $('#logo_n').html(data);
                }
            });
        });
        $('#btn_img_wave').on('change', function() {
            var url = '<?= XROOT ?>inc/upload_dev/wave-login';
            var property = document.getElementById('btn_img_wave').files[0];
            var image_name = property.name;
            var image_extension = image_name.split('.').pop().toLowerCase();
            var e = image_extension;
            if (e !== 'png' && e !== 'svg' && e !== 'jpg' && e !== 'jpeg') {
                toastr.error('Logo Extensi Harus [ png , svg, jpg, jpeg].');
                exit;
            }
            var form_data = new FormData();
            form_data.append("file", property);

            $.ajax({
                url: url,
                method: 'POST',
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    toastr.success('img backround Berhasil Di Ganti.');
                    $('#wave_l').html(data);
                }
            });
        });
    });
    //===========================================
</script>