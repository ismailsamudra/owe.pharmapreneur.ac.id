<link rel="stylesheet" href="<?= XROOT ?>script/lte/css/adminlte.min.css">
<?php index('mobile'); ?>
<style>
    .wid-mob1 {
        top: 0rem;
        position: sticky;
        height: 234px;
        z-index: 1000
    }

    .wid-mob2 {
        bottom: 0rem;
        position: fixed;
        height: 50px;
        z-index: 1000
    }

    img {
        border-radius: 20%;
    }

    .bg-1 {
        background-color: <?= color('primary-a'); ?>;
        color: <?= color('primary-b'); ?>;
    }
</style>
<!-- <a href="javascript:void(0);" onclick="history.back()" class="btn-sm bt-1 float-left" title="Back"><i class="fa fa-arrow-left"></i></a> -->
<!-- TOP NAVIGASI START -->
<div class="bg-1 card-footer col-md-12 wid-mob1">
    <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" width="40">
    <strong><?= inc('app-name') ?></strong>
    <a href="#" class="btn-sm bt-1 float-right" title="Logout" data-toggle="modal" data-target="#logout">
        <i class="fa fa-power-off"></i>
    </a>
    <a href="javascript:void(0);" class="btn-sm bt-1 mr-2 float-right" title="Ganti Password" onclick="g_pass();">
        <i class="fa fa-key"></i>
    </a>
    <br>
    <center>
        <?php
        $ft = (me('foto') == null) ? me('jk') . '.png' : me('foto');
        $foto = (me() == '28071986') ? $ft : XROOT . 'img/avatar/' . $ft;
        if (me() == '28071986' || me() == '1') {
            echo '<img src="' . $foto . '" width="80" title="' . me('nama') . '"><br>';
        } else {
            echo '<a href="' . XROOT . 'users/biodata"><img src="' . $foto . '" width="80" title="' . me('nama') . '"></a><br>';
        }
        ?>
        <strong><?= me('nama'); ?></strong><br>
        <?= me('hp'); ?><br>
    </center>
    <div class="row">
        <div class="col-6">
            <div id="jam"></div>
        </div>
        <div class="col-6">
            <div class="float-right"><?= date("d M Y") ?></div>
        </div>
    </div>
</div>
<div class="card-footer col-md-12 wid-mob2 bg-1">
    <strong>Copyright © <?= date("Y"); ?> <?= inc('nama-instansi') ?>.</strong>
</div>
<!-- TOP NAVIGASI END -->
<div class="container mt-2">

    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

            <!--========== SIDEBAR DB START ==========-->
            <?php
            if (me() != '28071986' && me() != '1') {
                echo '    
        <li class="nav-item">
        <a href="users/biodata" class="nav-link">
        <i class="nav-icon fa fa-id-card"></i>
        <p>
        BIODATA SAYA
        </p>
        </a>
        </li> ';
            }
            ?>
            <?php
            $ck_level = num_rows('engine', en64('level="' . me('level') . '"'));
            $ck_akses = num_rows('engine', en64('akses="' . me('akses') . '"'));
            if (me() != '28071986') {
                ($ck_level > 0) ?: go('logout');
                if ($ck_akses == 0) {
                    update('users', ['akses' => akses_d(me('level'))], ['id' => me()]);
                }
            }
            if ($ck_akses > 0) {
                $side1 = db('temp_sidebar')->orderBy('col1', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '1'])->getResult();
                foreach ($side1 as $a) {
                    if ($a->role == '1') {
                        echo '
                    <li class="nav-item">
                    <a href="' . $a->url . '" class="nav-link">
                    <i class="nav-icon ' . $a->icon . '"></i>
                    <p>
                    ' . $a->nama . '
                    </p>
                    </a>
                    </li> 
                    ';
                    } else {
                        echo '
                    <li class="nav-item">
                    <a href="#" class="nav-link">
                    <i class="nav-icon ' . $a->icon . '"></i>
                    <p>
                    ' . $a->nama . '
                    <i class="fas fa-angle-left right"></i>
                    </p>
                    </a>
                    <ul class="nav nav-treeview">  
                    ';
                        $side2 = db('temp_sidebar')->orderBy('col2', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '2', 'group_1' => $a->id])->getResult();
                        foreach ($side2 as $b) {
                            if ($b->role == '1') {
                                echo '
                            <li class="nav-item">
                            <a href="' . $b->url . '" class="nav-link">
                           <i class="nav-icon ' . $b->icon . '"></i>
                            <p>
                            ' . $b->nama . '
                            </p>
                            </a>
                            </li> 
                            ';
                            } else {
                                echo '
                            <li class="nav-item ">
                            <a href="#" class="nav-link">
                            <i class="nav-icon ' . $b->icon . '"></i>
                            <p>
                            ' . $b->nama . '
                            <i class="fas fa-angle-left right"></i>
                            </p>
                            </a>
                            <ul class="nav nav-treeview">  
                            ';
                                $side3 = db('temp_sidebar')->orderBy('col3', 'ASC')->getWhere(['status' => 'true', me('akses') => '1', 'colum' => '3', 'group_1' => $b->id])->getResult();
                                foreach ($side3 as $c) {
                                    echo '
                                    <li class="nav-item">
                                    <a href="' . $c->url . '" class="nav-link">
                                    <i class="nav-icon ' . $c->icon . '"></i>
                                    <p>
                                    ' . $c->nama . '
                                    </p>
                                    </a>
                                    </li> 
                                    ';
                                }
                                echo '</ul></li>';
                            }
                        }
                        echo '</ul></li>';
                    }
                }
            }
            ?>
            <!--========== SIDEBAR DB END ==========-->
            <?php
            if (me() == '28071986' || me() == '1') {
                echo '
<!--========== SIDEBAR ADMIN START ==========-->
<li class="nav-item ">
<a href="#" class="nav-link">
<i class="nav-icon fab fa-staylinked"></i>
<p>
Menu System
<i class="fas fa-angle-left right"></i>
</p>
</a>
<ul class="nav nav-treeview">            

<li class="nav-item">
<a href="inc/m_book" class="nav-link">
    <i class="nav-icon fa fa-book"></i>
    <p>
        EDIT M-BOOK
    </p>
</a>
</li>

<li class="nav-item">
<a href="inc/control" class="nav-link">
    <i class="nav-icon fab fa-whmcs"></i>
    <p>
        CONTROL SETTING
    </p>
</a>
</li>

<li class="nav-item">
    <a href="inc/apps" class="nav-link">
        <i class="nav-icon fab fa-joget"></i>
        <p>
            SETTING APPS
        </p>
    </a>
</li>

<li class="nav-item">
    <a href="inc/android" class="nav-link">
        <i class="nav-icon fab fa-android"></i>
        <p>
            DATA ANDROID
        </p>
    </a>
</li>

<li class="nav-item">
    <a href="inc/color" class="nav-link">
        <i class="nav-icon fa fa-paint-brush"></i>
        <p>
            UBAH WARNA
        </p>
    </a>
</li>

<li class="nav-item">
    <a href="inc/smtp_email" class="nav-link">
        <i class="nav-icon far fa-envelope"></i>
        <p>
            SMTP EMAIL
        </p>
    </a>
</li>

</ul> 
</li> 
<!--========== SIDEBAR ADMIN END ==========-->   
    ';
            }
            if (me() == '28071986') {
                echo '
<!--========== SIDEBAR ADMIN START ==========-->
<li class="nav-item ">
<a href="#" class="nav-link">
<i class="nav-icon fab fa-resolving"></i>
<p>
MENU DEVELOPMENT
<i class="fas fa-angle-left right"></i>
</p>
</a>
<ul class="nav nav-treeview">

<li class="nav-item">
<a href="init/engine" class="nav-link">
<i class="nav-icon fab fa-react"></i>
<p>
USER ENGINE
</p>
</a>
</li>

<li class="nav-item">
<a href="init/sidebar" class="nav-link">
<i class="nav-icon fa fa-th-list"></i>
<p>
SIDEBAR
</p>
</a>
</li>

<li class="nav-item">
<a href="init/keygen" class="nav-link">
<i class="nav-icon fa fa-key"></i>
<p>
KEYGEN
</p>
</a>
</li>

</ul>
</li>
<!--========== SIDEBAR ADMIN END ==========-->
    ';
            }
            ?>
            <li class="nav-item">
                <a href="users/m_book" class="nav-link">
                    <i class="nav-icon fa fa-book"></i>
                    <p>
                        MANUAL BOOK
                    </p>
                </a>
            </li>
        </ul>
    </nav>
</div>

<script src="<?= XROOT ?>script/modal.js"></script>
<!-- BODY START -->
<script src="<?= XROOT ?>script/lte/js/adminlte.js"></script>
<!-- BODY END -->

<script type="text/javascript">
    //=============================
    if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
        toastr.success('<?= session()->getFlashdata('info'); ?>')
    }
    if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
        toastr.error('<?= session()->getFlashdata('error'); ?>')
    }
    //=============================
</script>