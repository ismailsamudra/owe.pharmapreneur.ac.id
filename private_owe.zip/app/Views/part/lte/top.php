<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/lte/css/adminlte.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/owlcarousel/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/overlayScrollbars/css/OverlayScrollbars.min.css">
    <?php include 'css.php' ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed" data-panel-auto-height-mode="height" oncontectmenu="return false">

    <!-- LOADER START -->
    <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__wobble" src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="<?= inc('app-name') ?>" height="100" width="100">
    </div>
    <!--- LOADER END --->
    <div class="wrapper">

        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="javascript:void(0);" class="btn btn-outline-dark  mr-2">
                        <div id="jam"></div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);" class="btn btn-outline-dark mr-2" title="Ganti Password" onclick="g_pass();">
                        <i class="fa fa-key text-warning"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="javascript:void(0);" class="btn btn-outline-dark mr-2" title="Kunci" onclick="lock();">
                        <i class="fa fa-lock text-info"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a class="btn btn-outline-success mr-2" data-widget="fullscreen" href="javascript:void(0);" role="button" title="Fullscreen">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="btn btn-outline-danger mr-2" title="Logout" data-toggle="modal" data-target="#logout">
                        <i class="fa fa-power-off"></i>
                    </a>
                </li>
            </ul>
        </nav>