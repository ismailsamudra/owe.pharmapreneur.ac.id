<script type="text/javascript" src="<?= XROOT ?>script/login/main.js"></script>
<script type="text/javascript">
    //=============================
    if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
        toastr.success('<?= session()->getFlashdata('info'); ?>')
    }
    if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
        toastr.error('<?= session()->getFlashdata('error'); ?>')
    }
    //=============================
</script>
<style>
    .modal {
        z-index: 3000;
    }
</style>
</body>
<!--START Modal 1-->
<div class="modal fade" id="load" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <br>
        <br>
        <br>
        <br>
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif" width="140">
        </center>
    </div>
</div>
<!-- End Modal 1-->

</html>