<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
    <?php include 'css.php' ?>
</head>

<body>