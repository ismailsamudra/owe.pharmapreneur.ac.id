<!-- <style>
    .sidebar-light-costume .nav-sidebar>.nav-item>.nav-link.active {
        background-color: <?= color('primary-a'); ?>;
        color: <?= color('primary-b'); ?>;
    }

    .sidebar-light-costume .nav-sidebar.nav-legacy>.nav-item>.nav-link.active {
        border-color: <?= color('primary-a'); ?>;
    }
</style> -->