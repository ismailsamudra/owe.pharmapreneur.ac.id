<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a id="btnadd"></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="false" pagination="true" url="<?= XROOT ?>admin_web/get_berita" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="id" width="100%" formatter="show_res" sortable="true"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
            <div class="col-12" id="fo2">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="save();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="id" name="id">
                    <div class="card col my-1">
                        <div class="row">
                            <div class="col-12">
                                <small><strong>Judul</strong></small>
                            </div>
                            <div class="col-12 mb-2">
                                <input type="text" class="form-control" placeholder="Input Judul.." style="height: 24px;" id="judul" name="judul">
                            </div>
                        </div>
                    </div>
                    <small><strong>Content</strong></small>
                    <textarea name="content" id="content" cols="30" rows="8" class="form-control"></textarea>
                </form>
            </div>
            <div class="col-12" id="fo3">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head2"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="crop();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <form id="fm2" method="post" enctype="multipart/form-data">
                    <img id="temp_foto" name="img"></img>
                </form>
            </div>
        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
                Tombol Save Berada Pada Kolom Kanan Atas di samping tombol close
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- TOOLBAR START -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-5">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <script>
                //-----------------------------------------start
                function doSearchCustomer() {
                    $('#dguser').datagrid('load', {
                        search_customer: $('#searchCustomer').val()
                    });
                }
                //-----------------------------------------end
            </script>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- TOOLBAR END -->
<style>
    .consta>input {
        display: none;
    }
</style>
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <!-- <span class=""> -->
    <label for="thumbnail" class="consta">
        <a class="btn-sm form-control" plain="true"><i class="fa fa-image mr-2"></i>
            Ganti Thumbnail
        </a>
        <input type="file" name="thumbnail" id="thumbnail" onchange="thumbnail();" accept="image/*">
    </label>
    <!-- </span> -->
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<!---------------------------croppie start--------------------------------->
<script src="<?= XROOT ?>script/crop/croppie.min.js"></script>
<!---------------------------croppie end----------------------------------->
<script type="text/javascript">
    $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    $('#fo2').hide();
    $('#fo3').hide();
    $('#fo1').show();
    //-----------------------------------------start
    function hid() {
        $('#fm').form('clear');
        $('#temp_foto').croppie('destroy');
        $('#fo2').hide();
        $('#fo3').hide();
        $('#fo1').show();
        $('#dguser').datagrid('reload');
        $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    }
    //-----------------------------------------end
    $('#content').summernote({
        height: 500,
        // themes:paper,
        airMode: false
    })
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            gambar = (row.img == '') ? 'default1.png' : row.img;
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-2 col-6">
                       <img src="<?= XROOT ?>img/web/berita/` + gambar + `" width="100%">
                    </div>
                    <div class="col-md-10 col-12">
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>Tampikan Di Web</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + status + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>TANGGAL POST</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + row.time + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>VIEW</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + row.view + `</strong>  
                            </div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-md-2">
                                <small>JUDUL</small>
                            </div>
                            <div class="col-md-10">
                            <textarea cols="30" rows="2" class="form-control iwhite" readonly>` + row.judul + `</textarea> 
                            </div>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            `;
            if (row["id"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#fo1').hide();
        $('#fo3').hide();
        $('#fo2').show();
        $('#btnadd').html('');
        $('#content').summernote('code', '');
        $("#head").html('<small class="float-left"><i class="fa fa-plus mr-2"></i>Tambah Data</small>')
        document.getElementById("id").value = 'insert';
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#fo1').hide();
            $('#fo3').hide();
            $('#fo2').show();
            $('#btnadd').html('');
            $('#content').summernote('code', row.content);
            $("#head").html('<small class="float-left"><i class="fa fa-edit mr-2"></i>Edit Data</small>');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>ID : ' + row.id, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/status_berita", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ID : ' + row.id, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/del_berita", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        ($('#judul').val() == '') ? [msg('Error', 'judul harus di isi'), $('#judul').focus(), exit] : '';
        ($('#content').val() == '') ? [msg('Error', 'Content harus di isi'), $('#content').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_berita',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    ($('#id').val() == 'insert') ? hid(): '';
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                document.getElementById('id').value = row.id;
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
    //===========================================
    function thumbnail() {
        $("#head2").html('<small class="float-left"><i class="fa fa-image mr-2"></i>Ganti Thumbnail</small>');
        $('#fo1').hide();
        $('#fo2').hide();
        $('#fo3').show();
        var property = document.getElementById('thumbnail').files[0];
        var name = property.name;
        var extension = name.split('.').pop().toLowerCase();
        var e = extension;
        if (e !== 'png' && e !== 'jpg' && e !== 'jpeg' && e !== 'gif' && e !== 'webp' && e !== 'svg') {
            $('#temp_foto').croppie('destroy');
            msg('Error !', 'Extensi Gambar Harus [ png,jpg,jpeg,gif,webp,svg ].');
            exit;
        }
        $image_crop = $('#temp_foto').croppie({
            enableExif: true,
            viewport: {
                width: 400,
                height: 400,
                type: 'square'
            }, //circle 
            boundary: {
                width: 400,
                height: 400
            },
            // enableResize: true,
        });
        var reader = new FileReader();
        reader.onload = function(event) {
            $image_crop.croppie('bind', {
                url: event.target.result
            }).then(function() {
                console.log('jQuery bind complete');
            });
        }
        reader.readAsDataURL(property);
        // $('#foto').modal('show');
    }
    //===========================================
    //==========================================================
    function crop() {
        var id = document.getElementById('id').value;
        $image_crop.croppie('result', {
            type: 'canvas',
            size: 'viewport'
        }).then(function(response) {
            $.ajax({
                url: "<?= XROOT ?>admin_web/thumbnail_berita",
                type: "POST",
                data: {
                    "image": response,
                    "id": id
                },
                success: function(data) {
                    hid();
                    msg('Success !', 'Gambar Thumbnail Berhasil Di Ganti.')
                }
            });
        });
    }
    //==========================================================
</script>