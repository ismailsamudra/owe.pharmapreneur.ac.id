<img class="wave" src="<?= XROOT ?>img/dev/<?= inc('wave-login') ?>">
<div class="container">
    <div class="img">
        <div class="m-2">
            <?= inc('desk-login'); ?>
        </div>
    </div>
    <div class="login-content">
        <form id="fm">
            <div id="content"></div>
            <div id="bodi">
                <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>">
                <h5 class="title"><?= inc('app-name') ?></h5>
                <strong class="pri-c">HALAMAN LUPA PASSWORD</strong>
                <br>
                <br>

                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-envelope pri-c"></i></span>
                    </div>
                    <input type="email" class="form-control" id="email" placeholder="Email">
                </div>
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fab fa-whatsapp pri-c"></i></span>
                    </div>
                    <input type="text" class="form-control" id="hp" placeholder="No.Hp [ Whatsapp ]">
                </div>

                <br>
                <?php echo (inc('register') == 'true') ? '<a href="' . XROOT . 'register" class="float-left pri-c"><strong>Registrasi</strong></a>' : ''; ?>
                <a href="<?= XROOT ?>login" class="float-right pri-c"><strong>Login</strong></a>
                <br>
                <center>
                    <a href="javascript:void(0);" onclick="forgot()" class="btn">Kirim</a>
                </center>
                <?php echo (inc('web_status') == 'true') ? '<a href="' . XROOT . '"><strong>Website</strong></a>' : ''; ?>
                <strong>© <?= date("Y") . ' ' . inc('nama-instansi') ?> .All Rights Reserved.</strong>
            </div>
        </form>
    </div>

</div>
<script>
    function reset() {
        var otp = $("input[type='text'][name='otp']").val();
        (otp) ? '' : [toastr.error('Kode OTP Belum Di isi.'), $("input[type='text'][name='otp']").focus(), exit];
        $("#bodi").hide()
        $("#content").html(`
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif">
            <br>
            <br>
            <small><strong>Harap Menunggu...</strong></small>
        </center>
        `);
        $.post("<?= XROOT ?>portal/reset_pass", {
            otp
        }, function(result) {
            if (result.success) {
                $('#bodi').hide();
                $('#content').html(`
                    <h5>Reset Password Berhasil !</h5>
                    Password Baru telah Dikirim ke Email Atau No.Whatsapp yang telah anda daftarkan.
                    <br>
                    <br>
                    <a href="<?= XROOT ?>login" class="btn-sm btn-dark bg-1-h">Login</a>
                    `);
            } else {
                $('#content').html(`
                    <h5>Request Kode OTP Berhasil !</h5>
                    Kode OTP telah Dikirim ke Email Atau No.Whatsapp yang telah anda daftarkan.
                    <br>
                    <br>
                    Input Kode OTP Untuk Reset Password
                    <br>
                    <br>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-key pri-c"></i></span>
                        </div>
                        <input type="text" name="otp" class="form-control" id="otp" placeholder="Kode OTP">
                    </div>
                    <br>
                <a href="javascript:void(0);" onclick="reset();" class="btn-sm btn-dark bg-1-h">Reset</a>
                    `);
                toastr.error(result.errorMsg);
            }
        }, 'json');

    }

    function forgot() {
        var email = document.getElementById("email").value;
        var hp = document.getElementById("hp").value;
        (email) ? '' : [toastr.error('Email Belum Di isi.'), $('#email').focus(), exit];
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (!email.match(mailformat)) {
            toastr.error('Format Email Salah');
            $('#email').focus();
            exit;
        }
        (hp) ? '' : [toastr.error('No.Hp Belum Di isi.'), $('#hp').focus(), exit];
        $("#bodi").hide()
        $("#content").html(`
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif">
            <br>
            <br>
            <small><strong>Harap Menunggu...</strong></small>
        </center>
        `);
        $.post("<?= XROOT ?>portal/get_otp", {
            email,
            hp
        }, function(result) {
            if (result.success) {
                $('#bodi').hide();
                $('#content').html(`
                    <h5>Request Kode OTP Berhasil !</h5>
                    Kode OTP telah Dikirim ke Email Atau No.Whatsapp yang telah anda daftarkan.
                    <br>
                    <br>
                    Input Kode OTP Untuk Reset Password
                    <br>
                    <br>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-key pri-c"></i></span>
                        </div>
                        <input type="text" name="otp" class="form-control" id="otp" placeholder="Kode OTP">
                    </div>
                    <br>
                <a href="javascript:void(0);" onclick="reset();" class="btn-sm btn-dark bg-1-h">Reset</a>
                    `);
            } else {
                $("#bodi").show()
                $("#content").html('');
                toastr.error(result.errorMsg);
            }
        }, 'json');

    }
    $('#hp').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
    $('#content').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>