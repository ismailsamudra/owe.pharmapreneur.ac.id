<?php

/*
 | --------------------------------------------------------------------
 | App Namespace
 | --------------------------------------------------------------------
 |
 | This defines the default Namespace that is used throughout
 | CodeIgniter to refer to the Application directory. Change
 | this constant to change the namespace that all application
 | classes should use.
 |
 | NOTE: changing this will require manually modifying the
 | existing namespaces of App\* namespaced-classes.
 */
defined('APP_NAMESPACE') || define('APP_NAMESPACE', 'App');

/*
 | --------------------------------------------------------------------------
 | Composer Path
 | --------------------------------------------------------------------------
 |
 | The path that Composer's autoload file is expected to live. By default,
 | the vendor folder is in the Root directory, but you can customize that here.
 */
defined('COMPOSER_PATH') || define('COMPOSER_PATH', ROOTPATH . 'vendor/autoload.php');

/*
 |--------------------------------------------------------------------------
 | Timing Constants
 |--------------------------------------------------------------------------
 |
 | Provide simple ways to work with the myriad of PHP functions that
 | require information to be in seconds.
 */
defined('SECOND') || define('SECOND', 1);
defined('MINUTE') || define('MINUTE', 60);
defined('HOUR')   || define('HOUR', 3600);
defined('DAY')    || define('DAY', 86400);
defined('WEEK')   || define('WEEK', 604800);
defined('MONTH')  || define('MONTH', 2592000);
defined('YEAR')   || define('YEAR', 31536000);
defined('DECADE') || define('DECADE', 315360000);

/*
 | --------------------------------------------------------------------------
 | Exit Status Codes
 | --------------------------------------------------------------------------
 |
 | Used to indicate the conditions under which the script is exit()ing.
 | While there is no universal standard for error codes, there are some
 | broad conventions.  Three such conventions are mentioned below, for
 | those who wish to make use of them.  The CodeIgniter defaults were
 | chosen for the least overlap with these conventions, while still
 | leaving room for others to be defined in future versions and user
 | applications.
 |
 | The three main conventions used for determining exit status codes
 | are as follows:
 |
 |    Standard C/C++ Library (stdlibc):
 |       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
 |       (This link also contains other GNU-specific conventions)
 |    BSD sysexits.h:
 |       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
 |    Bash scripting:
 |       http://tldp.org/LDP/abs/html/exitcodes.html
 |
 */

defined('EXIT_SUCCESS')        || define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          || define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         || define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   || define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  || define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') || define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     || define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       || define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      || define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      || define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code
include 'Msg_temp.php';

/*
 |--------------------------------------------------------------------------
 | CURL
 |--------------------------------------------------------------------------
 */

function init_curl($url, $data, $headers = null)
{
    $data = json_encode($data);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    if ($headers) {
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    } else {
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type:application/json']);
    }
    $resp = curl_exec($curl);
    return $resp;
    curl_close($curl);
}

/*
 |--------------------------------------------------------------------------
 | Timing Constants
 |--------------------------------------------------------------------------
 */
function protokol()
{
    if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
        $protocol = 'https://';
    } else {
        $protocol = 'http://';
    }
    return $protocol;
}
function xurl()
{
    $con = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || isset($_ENV['FORCE_HTTPS'])) ? 'https' : 'http';
    $con .= '://' . $_SERVER['HTTP_HOST'];
    $con .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    return $con;
}
define('XURL', xurl());
// define('XURL', 'http://localhost:8080/');
/*
 |--------------------------------------------------------------------------
 | KODE INIT
 |--------------------------------------------------------------------------
 */
function en64($val)
{
    return base64_encode($val);
}
function de64($val)
{
    return base64_decode($val);
}
function akses_d($lvl)
{
    $db = \Config\Database::connect();
    $builder = $db->table('engine');
    $o = $builder->getWhere(['level' => $lvl, 'role' => 'DEFAULT_AKSES'], 1)->getRow()->akses;
    return $o;
}
function level_n($lvl)
{
    $db = \Config\Database::connect();
    $builder = $db->table('engine');
    $o = $builder->getWhere(['level' => $lvl, 'role' => 'DEFAULT_AKSES'], 1)->getRow()->level_name;
    return $o;
}
function level_id($akses)
{
    $db = \Config\Database::connect();
    $builder = $db->table('engine');
    $o = $builder->getWhere(['akses' => $akses], 1)->getRow()->level;
    return $o;
}
function an($val = null)
{
    $alphabet = '1234567890';
    $pass = array();
    $alpha_length = strlen($alphabet) - 1;
    for ($i = 0; $i < $val; $i++) {
        $n = rand(0, $alpha_length);
        $pass[] = $alphabet[$n];
    }
    $an = implode($pass);
    return $an;
}
function api_key()
{
    $api_key = sha1(date("Y-m-d H:i:s") . rand(100000, 999999));
    return $api_key;
}
function select_where($tb, $wr, $val, $class = null)
{
    if ($class == null) $class = 'form-control';
    $oo = db($tb)->getWhere($wr)->getResult();
    if ($class == 'card') {
        echo ' 
        <div class="card mb-2">
        <div class="row col">';
        $no = 1;
        foreach ($oo as $o) {
            echo '<div class="col-md-12">
                        <input type="radio" name="' . $tb . '" id="' . $tb . $no++ . '" class="mr-2" value="' . $o->id . '">' . $o->$val . '
                    </div>';
        }
        echo '</div>
        </div>';
    } else {
        echo '<select name="' . $tb . '" id="' . $tb . '" class="' . $class . '">';
        foreach ($oo as $o) {
            echo '<option value="' . $o->id . '">' . $o->$val . '</option>';
        }
        echo '</select>';
    }
}
function select($id, $wr = null, $class = null)
{
    if ($class == null) $class = 'form-control';
    if ($id == 'akses') {
        $oo = db('engine')->getWhere($wr)->getResult();
        if ($class == 'card') {
            echo ' 
            <div class="card mb-2">
            <div class="row col">';
            $no = 1;
            foreach ($oo as $o) {
                echo '<div class="col-md-12">
                            <input type="radio" name="akses" id="akses' . $no++ . '" class="mr-2" value="' . $o->akses . '">' . $o->level_name . '.' . $o->akses_name . '
                        </div>';
            }
            echo '</div>
            </div>';
        } else {
            echo '<select name="akses" id="akses" class="' . $class . '">';
            foreach ($oo as $o) {
                echo '<option value="' . $o->akses . '">' . $o->level_name . '.' . $o->akses_name . '</option>';
            }
            echo '</select>';
        }
    }
    if ($id == 'jk') {
        echo '
            <div class="card mb-2">
                <div class="row col">
                    <div class="col-md-6">
                        <input type="radio" name="jk" id="jk1" class="mr-2" value="L">Laki-Laki
                    </div>
                    <div class="col-md-6">
                        <input type="radio" name="jk" id="jk2" class="mr-2" value="P">Perempuan
                    </div>
                </div>
            </div>
            ';
    }
}
define('XSQL', 'production');
// KEY-GEN
define("KEY_VERSI", 'V.1.1');
function enkey($val = null)
{
    $h = base64_encode($val);
    $e1 = ["m", "a", "i", "e", "l", "M", "A", "I", "E", "L", "="];
    $e2 = ["米", "一種", "一世", "電子", "升電", "年時", "小時", "警告", "簡歷", "點", "每"];
    $h0 = str_replace($e1, $e2, $h);
    $key = base64_encode($h0);
    return $key;
}
function dekey($val = null)
{
    $h = base64_decode($val);
    $e1 = ["m", "a", "i", "e", "l", "M", "A", "I", "E", "L", "="];
    $e2 = ["米", "一種", "一世", "電子", "升電", "年時", "小時", "警告", "簡歷", "點", "每"];
    $h0 = str_replace($e2, $e1, $h);
    $key = base64_decode($h0);
    return $key;
}
// KEY-GEN
include 'Portal.php';
function model($name)
{
    $a = '\App\Models\x' . $name;
    $b = str_replace("x", "", $a);
    $db = new $b();
    return $db;
}
function cek_hp($no)
{
    $db = \Config\Database::connect();
    $query = $db->query('SELECT * FROM users WHERE hp = "' . $no . '"');
    $res = $query->getNumRows();
    return ($res > 0) ? true : false;
}
function cek_email($email)
{
    $db = \Config\Database::connect();
    $query = $db->query('SELECT * FROM users WHERE email = "' . $email . '"');
    $res = $query->getNumRows();
    return ($res > 0) ? true : false;
}
function cek_email_hp($email, $hp)
{
    $db = \Config\Database::connect();
    $query = $db->query('SELECT * FROM users WHERE email = "' . $email . '" AND hp = "' . $hp . '"');
    $res = $query->getNumRows();
    return ($res > 0) ? true : false;
}
function num_rows($tb, $wr = null)
{
    /**
     * USE METHOD
     * num_rows('user', en64('status="true"'));
     */
    $db = \Config\Database::connect();
    if ($wr == null) {
        $query = $db->query('SELECT * FROM ' . $tb);
    } else {
        $and = de64($wr);
        $query = $db->query('SELECT * FROM ' . $tb . ' WHERE ' . $and);
    }
    return $query->getNumRows();
}
function get_result($tb, $wr = null, $js = null)
{
    /**
     * USE METHOD
     * $oo = get_result('user', en64("status='true'"),'json');
     */
    $db = \Config\Database::connect();
    if ($wr == null) {
        $query = $db->query('SELECT * FROM ' . $tb);
    } else {
        $and = de64($wr);
        $query = $db->query('SELECT * FROM ' . $tb . ' WHERE ' . $and);
    }
    if ($js == 'json') {
        return json_encode($query->getResult());
    } else {
        return $query->getResult();
    }
}
function get_row($tb, $wr = null, $js = null)
{
    /**
     * USE METHOD
     * $o = get_row('user', en64("id='999999999' && id='00000'"),'json');
     */
    $and = de64($wr);
    $db = \Config\Database::connect();
    $query = $db->query('SELECT * FROM ' . $tb . ' WHERE ' . $and . ' LIMIT 1');
    if ($js == 'json') {
        return json_encode($query->getRow());
    } else {
        return $query->getRow();
    }
}
function bintang($val)
{
    if ($val == 1) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($val == 2) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($val == 3) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($val == 4) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($val == 5) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    return '<i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
    exit;
}
function ranting($persen)
{
    if ($persen >= 95 && $persen <= 100) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($persen >= 90 && $persen < 95) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star-half mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($persen >= 80 && $persen < 90) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($persen >= 70 && $persen < 80) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    if ($persen >= 60 && $persen < 70) {
        return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
        exit;
    }
    return '<i class="fa fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i>
    <i class="far fa-star mr-2 text-warning"></i><br>
        ';
    exit;
}
/*
 |--------------------------------------------------------------------------
 | END LINE
 |--------------------------------------------------------------------------
 */