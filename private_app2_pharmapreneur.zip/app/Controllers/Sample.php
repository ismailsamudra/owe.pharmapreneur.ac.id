<?php

namespace App\Controllers;

class Sample extends BaseController
{
    public function __construct()
    {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        exit;
    }
    public function index()
    {
        dd(model('users')->findAll());
    }
    // CRUD START
    public function insert()
    {
        $data = [
            'id' => time(),
        ];
        insert('user', $data);
    }
    public function update()
    {
        $data = [
            'sync' => date("YmdHis"),
        ];
        update('user', $data, ['id' => '1649676069']);
    }
    public function delete()
    {
        $id = [
            'id' => '1649676069',
        ];
        delete('user', $id);
    }
    // CRUD END
    public function xxx($val = null)
    {
        $n = en64(XURH);
        echo num_rows('dt_sidebar', en64('colum="2" && role="1" && status="true"')) . "<br>";
        echo $n . "<br>";
        echo de64($n) . "<br>";
        echo XURI . "<br>";
        echo XURH;
    }
    public function ooo()
    {
        $oo = get_result('user');
        // $oo = get_result('user', en64("status='true' && hp='085555'"));
        // echo json_encode($oo);
        foreach ($oo as $o) {
            echo $o->nama . '<br>';
        }
    }
    public function oo()
    {
        $o = get_row('user', en64("id='999999999'"), 'json');
        echo $o;
    }
}
