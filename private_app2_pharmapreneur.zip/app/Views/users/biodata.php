<link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onClick="update();" class="btn-sm bt-1 float-left" title="EDIT"><i class="fa fa-edit"></i></a>
            <h5><i class="fa fa-id-card mr-2"></i> <strong>BIODATA SAYA</strong>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>

</div>
<?php
$x = one('users', $id);
$o = one($x->level, $id);
$tb = $x->level . '_schema';
$foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto;
?>
<?php $rr = db($tb)->orderBy('row', 'ASC')->whereNotIn('id', ['akses'])->getWhere(['status' => 'true'])->getResult(); ?>
<!-- TOP NAVIGASI END -->
<style>
    .image_upload>input {
        display: none;
    }

    /* input[type=text]{width:220px;height:auto;} */
    #logo_p>img {
        border-radius: 10%;
    }
</style>
<!-- BODY START -->
<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="text-danger">
                <small>
                    <strong>
                        ATTENTION ! <br>
                        Admin tidak akan pernah membagikan informasi pribadi anda pada siapapun.
                    </strong>
                </small>
            </div>
        </div>
        <div class="col-12">
            <div class="row m-1">
                <div class="col-md-3">
                    <div class="row">
                        <div class="mb-2 col-md-12">

                            <div id="cr1">
                                <div class="">
                                    <div class="my-3">
                                        <a href="javascript:void(0);" class="btn-sm crop_image bg-1"> <i class="fa fa-crop mr-2"></i>Crop</a>
                                        <a href="javascript:void(0);" onclick="cmod();" class="btn-sm bg-1 float-right"><i class="fa fa-times"></i></a>
                                    </div>
                                    <img id="temp_foto"></img>
                                </div>
                            </div>
                            <div class="text-center" id="cr2">
                                <!-- <div class="container"> -->
                                <span class="image_upload">
                                    <label for="btn_logo_pl">
                                        <a class="btn" rel="nofollow" id="btn_img">
                                            <div id="logo_p">
                                                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" width="100%">
                                            </div>
                                        </a>
                                    </label>
                                    <input type="file" name="btn_logo_p" id="btn_logo_pl">
                                </span>
                                <!-- </div> -->
                                <div class="small mb-2">
                                    <small>
                                        <strong>
                                            KLICK FOTO UNTUK MENGGANTI. <br>
                                        </strong>
                                        &nbsp;&nbsp;Extension : 'png','jpg','jpeg','gif','webp'
                                    </small>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <?php foreach ($rr as $r) : ?>
                        <?php
                        $id = $r->id;
                        $res = $o->$id;
                        if ($id == 'jk') {
                            $res = ($res == 'L') ? 'Laki-Laki' : $res = 'Perempuan';
                        }
                        if ($r->type == 'date') {
                            $res = date("d-m-Y", strtotime($o->$id));
                        }
                        ?>
                        <!-- BATAS GARIS 1 -->
                        <div class="row mb-1 mt-1">
                            <div class="col-md-4">
                                <div class="card table-responsive">
                                    <strong>&nbsp;&nbsp;<?= $r->label ?></strong>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card table-responsive">
                                    &nbsp;&nbsp;<?= $res ?>
                                </div>
                            </div>
                        </div>
                        <!-- BATAS GARIS 1 -->
                    <?php endforeach ?>
                    <!-- BATAS GARIS 1 -->
                    <div class="row mb-1 mt-1">
                        <div class="col-md-4">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;Level</strong>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;<?= level_n($x->level) ?></strong>
                            </div>
                        </div>
                    </div>
                    <!-- BATAS GARIS 1 -->
                    <!-- BATAS GARIS 1 -->
                    <div class="row mb-1 mt-1">
                        <div class="col-md-4">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;Tgl Register</strong>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;<?= date("d M Y", strtotime($o->sort)); ?></strong>
                            </div>
                        </div>
                    </div>
                    <!-- BATAS GARIS 1 -->
                </div>
                <div class="col-md-2">
                    <center>
                        <a href="javascript:void(0);" onclick="d_qr();">
                            <small><strong>UNDUH QRCODE</strong></small>
                            <div id="qrcode"></div>
                        </a>
                    </center>
                </div>
            </div>


        </div>

    </div>
    <!-- BODY END -->
    <!-- Start Modal 1 -->
    <div class="modal fade" id="foto" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content scrl">
                <a onclick="cmod();" class="btn" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
                <!-- <div id="cont1" class="container mt-3 mb-3">
                    <input type="file" id="upload_image" class="form-control" accept="image/*">
                </div> -->
                <!-- <div id="cont2" class="container mt-3 mb-3">
                    <a class="btn btn-outline-primary btn-sm crop_image d-block"> <i class="fa fa-crop mr-2"></i>Crop & Upload</a>
                </div> -->

            </div>
        </div>
    </div>
    <!-- End Modal 1-->
    <!-- Start Modal 1 -->
    <div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <div id="head"></div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body rol-300">
                    <form id="fm" method="post">
                        <input type="hidden" id="id" name="id" value="<?= $x->id ?>">
                        <div class="row">
                            <?php $ooo = db($tb)
                                ->orderBy('row', 'ASC')
                                ->whereNotIn('id', ['akses', 'email', 'hp'])
                                ->getWhere(['status' => 'true', 'group' => '1'])
                                ->getResult(); ?>
                            <?php $xxx = db($tb)
                                ->orderBy('row', 'ASC')
                                ->whereNotIn('id', ['akses', 'email', 'hp'])
                                ->getWhere(['status' => 'true', 'group' => '2'])
                                ->getResult(); ?>
                            <div class="col-md-6">
                                <?php
                                foreach ($ooo as $o1) {
                                    echo '<small>' . $o1->label . '</small>';
                                    if ($o1->type == 'script') {
                                        echo $o1->script;
                                    } else if ($o1->type == 'select') {
                                        select($o1->script);
                                    } else if ($o1->type == 'area') {
                                        echo '
                                        <textarea name="' . $o1->id . '" id="' . $o1->id . '" cols="30" rows="2" class="' . $o1->class . '" style="' . $o1->style . '" ' . $o1->sync . '></textarea>
                                        ';
                                    } else {
                                        echo '
                                                <input type="' . $o1->type . '" class="' . $o1->class . '" class="' . $o1->style . '" id="' . $o1->id . '" name="' . $o1->id . '" ' . $o1->sync . '>
                                            ';
                                    }
                                }
                                ?>
                            </div>

                            <div class="col-md-6">
                                <?php
                                foreach ($xxx as $x1) {
                                    echo '<small>' . $x1->label . '</small>';
                                    if ($x1->type == 'script') {
                                        echo $x1->script;
                                    } else if ($x1->type == 'select') {
                                        select($x1->script);
                                    } else if ($x1->type == 'area') {
                                        echo '
                                            <textarea name="' . $x1->id . '" id="' . $x1->id . '" cols="30" rows="2" class="' . $x1->class . '" style="' . $x1->style . '" ' . $x1->sync . '></textarea>
                                            ';
                                    } else {
                                        echo '
                                            <input type="' . $x1->type . '" class="' . $x1->class . '" class="' . $x1->style . '" id="' . $x1->id . '" name="' . $x1->id . '" ' . $x1->sync . '>
                                            ';
                                    }
                                }
                                ?>

                            </div>
                            <div class="container">
                                <div class="text-danger"><small><strong>NB : </strong><br>Email Dan No.Hp Hanya Dapat di Ubah Lewat admin <br>Karna Merupakan Data Sensitife.</small></div>
                            </div>
                        </div>


                </div>
                <div class="modal-footer">
                    <button type="submit" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</button>
                </div>
                </form>


            </div>
        </div>
    </div>
    <!-- End Modal 1-->
    <!---------------------------croppie start--------------------------------->
    <script src="<?= XROOT ?>script/crop/croppie.min.js"></script>
    <!---------------------------croppie end----------------------------------->
    <script type="text/javascript">
        $('#cr1').hide();
        $('#cr2').show();

        function manual() {
            $('#manual').modal('show');
        }

        function cmod() {
            $('#cr1').hide();
            $('#cr2').show();
            $('#temp_foto').croppie('destroy');
        }

        function smod() {
            $('#foto').modal('show');
        }
        //-----------------------------------------start
        function update() {
            var url = '<?= XROOT ?>users/get_me';
            $.get(url, function(result) {
                if (result) {
                    $('#fm').form('load', result);
                    document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
                    $('#modal').modal('show');
                }
            }, 'json');

        }
        //-----------------------------------------end
        //-----------------------------------------start
        function all_history(id) {
            var url = '<?= XROOT ?>users/all_history/' + id;
            $.get(url, function(result) {
                if (result.success) {
                    var url2 = '<?= XROOT ?>user/del_history/' + result.id;
                    $('#dguser').datagrid('reload'); // reload the Vendor data
                    $.messager.show({ // show error message
                        title: 'Success !',
                        msg: 'data berhasil di unduh.'
                    });
                }
                window.location = url2;
            }, 'json');
        }
        //-----------------------------------------end
    </script>
    <script type="text/javascript">
        $('#foto').on('hidden.bs.modal', function() {
            $('#temp_foto').croppie('destroy');
        });
        //===========================================
        $(document).ready(function() {

            $('#btn_logo_pl').on('change', function() {
                $('#cr2').hide();
                $('#cr1').show();
                var property = document.getElementById('btn_logo_pl').files[0];
                var name = property.name;
                var extension = name.split('.').pop().toLowerCase();
                var e = extension;
                if (e !== 'png' && e !== 'jpg' && e !== 'jpeg' && e !== 'gif' && e !== 'webp') {
                    $('#cr1').hide();
                    $('#cr2').show();
                    $('#temp_foto').croppie('destroy');
                    toastr.error('Extensi foto Harus [ png,jpg,jpeg,gif,webp ].');
                    exit;
                }
                $image_crop = $('#temp_foto').croppie({
                    enableExif: true,
                    viewport: {
                        width: 200,
                        height: 240,
                        type: 'square'
                    }, //circle 
                    boundary: {
                        width: 200,
                        height: 240
                    }
                });
                var reader = new FileReader();
                reader.onload = function(event) {
                    $image_crop.croppie('bind', {
                        url: event.target.result
                    }).then(function() {
                        console.log('jQuery bind complete');
                    });
                }
                reader.readAsDataURL(property);
                // $('#foto').modal('show');
            });

        });
        //===========================================
        //==========================================================
        $('.crop_image').click(function(event) {
            var id = "<?= $x->id ?>";
            $image_crop.croppie('result', {
                type: 'canvas',
                size: 'viewport'
            }).then(function(response) {
                $.ajax({
                    url: "<?= XROOT ?>users/crop_img",
                    type: "POST",
                    data: {
                        "image": response,
                        "id": id
                    },
                    success: function(data) {
                        $('#foto').modal('hide');
                        $('#cr1').hide();
                        $('#cr2').show();
                        toastr.info('foto Berhasil Di Ganti.');
                        $('#logo_p').html(data);
                        $('#temp_foto').croppie('destroy');
                    }
                });
            });
        });
        //==========================================================
    </script>
    <script src="<?= XROOT ?>script/qr-code-styling.js"></script>
    <script src="<?= XROOT ?>script/show_qr2.js"></script>
    <script>
        var data = "<?= XURL . 'biodata/' . $x->id ?>";
        var logo = "<?= XROOT ?>img/instansi/<?= inc('logo-n') ?>";
        var color = "<?= color('qrcode-a') ?>";
        qrcode("qrcode", data, logo, color, '0');

        function d_qr() {
            download_qrcode(data, logo, color);
        }
        $('#hp').on('keypress', function(event) {
            return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
        });
    </script>