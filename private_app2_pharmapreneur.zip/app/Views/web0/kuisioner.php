<!DOCTYPE html>
<html lang="en">

<head>
    <title>KUISIONER</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/lte/css/adminlte.min.css">

    <![endif]-->
    <style>
        html,
        body {
            /*background-image: url('https://azkanadhifah.id/assets/wall2.jpg');*/
            background-color: <?= color('primary-a') ?>;
            background-size: cover;
            background-repeat: no-repeat;
            height: 100%;
            font-family: 'Numans', sans-serif;
        }

        .sufee-alert {
            background-color: rgba(0, 0, 0, 0.5) !important;
        }
    </style>
</head>

<body onload="load();">
<?php
$s_nama = session()->get('s_nama');
$s_email = session()->get('s_email');
$s_hp = session()->get('s_hp');
?>
    <!-- Services section -->
    <section class="service-section spad">
        <div class="container services">
            <br>
            <br>
            <div id="fo1">
            <center>
                <div class="card col-md-6 mb-2">
                    <small>
                        <img src="<?= XROOT ?>img/dev/testimonial_b.png" alt="testimonial" width="60" class="float-left m-2">
                        <strong class="float-left mt-2">
                            NAMA :<?= $s_nama ?> <br>
                            EMAIL :<?= $s_email ?><br>
                            HP/WA :<?= $s_hp ?><br>
                        </strong>
                    </small>
                </div>
                <div class="card col-md-6 mb-3">
                    <?= inc('desk_kuisioner') ?> </div>
                <?php $l = db('kuisioner_layanan')->getWhere(['status' => 'true'])->getResult() ?>
                <?php $no = 1;
                foreach ($l as $o) : ?>
                    <a href="javascript:void(0);" onclick="go(`<?= $o->id ?>`,`<?= $o->label ?>`,`<?= $o->icon ?>`);">
                        <div class="card col-md-6 mb-3 text-dark">
                            <strong>
                                <strong class="float-left"><?= $no++ ?> . </strong>
                                <strong><?= $o->label ?></strong>
                                <i class="fa fa-arrow-right mt-1 float-right"></i>
                            </strong>
                        </div>
                    </a>
                <?php endforeach ?>

                <div class="card col-md-6 mt-2">
                    <small>
                        <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="Klinik Azka Nadhifah" width="60" class="float-left mr-2">
                        <strong class="float-left mt-2"><?= inc('app-name') ?></strong>
                        <a href="<?= XROOT ?>"><strong class="float-right mt-2">Go Website</strong></a>
                    </small>
                </div>
            </center>
            </div>

        </div>
    </section>
    <!-- Services section end -->
    <script src="<?= XROOT ?>script/easyui/jquery.min.js"></script>
    <script src="<?= XROOT ?>script/easyui/jquery.easyui.min.js"></script>
    <script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
    <script src="<?= XROOT ?>script/lte/js/adminlte.js"></script>
    <script src="<?= XROOT ?>script/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        function load() {
            document.getElementById("star").value = '';
            var ses = "<?= $s_nama ?>";
            if (ses == '') {
                $('#user').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            }
        }

        function go(id, val,icon) {
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="'+icon+' mr-2"></i>' + val + '</h5>';
            document.getElementById("img_1").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_2").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_3").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_4").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_5").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("id_layanan").value = id;
            $('#tanda').modal({
                backdrop: 'static',
                keyboard: false
            });
        }

        function rant(val) {
            document.getElementById("img_1").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_2").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_3").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_4").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            document.getElementById("img_5").innerHTML = '<i class="far fa-star fa-2x mr-2"></i>';
            if (val == 'img_5') {
                document.getElementById("star").value = '5';
                document.getElementById("img_1").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_2").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_3").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_4").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_5").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
            }
            if (val == 'img_4') {
                document.getElementById("star").value = '4';
                document.getElementById("img_1").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_2").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_3").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_4").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
            }
            if (val == 'img_3') {
                document.getElementById("star").value = '3';
                document.getElementById("img_1").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_2").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_3").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
            }
            if (val == 'img_2') {
                document.getElementById("star").value = '2';
                document.getElementById("img_1").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
                document.getElementById("img_2").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
            }
            if (val == 'img_1') {
                document.getElementById("star").value = '1';
                document.getElementById("img_1").innerHTML = '<i class="fa fa-star fa-2x mr-2 text-warning"></i>';
            }
        }

        function submit() {
            var id_layanan = document.getElementById("id_layanan").value;
            var nama = document.getElementById("nama").value;
            var email = document.getElementById("email").value;
            var hp = document.getElementById("hp").value;
            var star = document.getElementById("star").value;
            var ulasan = document.getElementById("ulasan").value;
            if (star == '') {
                toastr.error('Anda Belum Memilih Ranting');
                exit;
            }
            $.post("<?= XROOT ?>kuisioner/save_bintang", {
                id_layanan,
                nama,
                email,
                hp,
                star,
                ulasan
            }, function(result) {
                if (result.success) {
                    document.getElementById("star").value = '';
                    toastr.info('Terima Kasih !!!')
                    $('#tanda').modal('hide');
                } else {
                    toastr.error(result.errorMsg);
                }
            }, 'json');
        }
    </script>
    <!-- Start Modal Login -->
    <div class="modal fade" id="user" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="_user"><i class="fa fa-id-card mr-2"></i>Input Biodata</h5>
                </div>
                <div class="modal-body">

                <form action="" method="post">
                        <small><strong>Nama</strong></small>
                            <input type="text" class="form-control mb-1" name="nama" id="nama" value="<?= $s_nama ?>" required>
                        <small><strong>Email</strong> Optional</small>
                            <input type="text" class="form-control mb-1" name="email" id="email" value="<?= $s_email ?>">
                        <small><strong>No HP/WA</strong> Optional</small>
                            <input type="text" class="form-control mb-1" name="hp" id="hp" value="<?= $s_hp ?>">

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-dark btn-block">OK</button>
                </div>

                </form>

            </div>
        </div>
    </div>
    <!-- End Modal Login-->
    <input type="hidden" id="id_layanan">
    <input type="hidden" id="star">
    <!-- Start Modal Login -->
    <div class="modal fade" id="tanda" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div id="head"></div>
                </div>
                <div class="modal-body">

                    <center class="m-2">
                        <i id="img_1" onclick="rant(this.id);"></i>
                        <i id="img_2" onclick="rant(this.id);"></i>
                        <i id="img_3" onclick="rant(this.id);"></i>
                        <i id="img_4" onclick="rant(this.id);"></i>
                        <i id="img_5" onclick="rant(this.id);"></i>
                    </center>

                    <label>Ulasan / Komentar Anda</label>
                    <textarea name="ulasan" id="ulasan" cols="30" rows="4" class="form-control"></textarea>
                </div>

                <div class="modal-footer">
                    <a onclick="submit()" class="btn btn-dark btn-block text-white">OK</a>
                </div>

            </div>
        </div>
    </div>
    <!-- End Modal Login-->
</body>

</html>